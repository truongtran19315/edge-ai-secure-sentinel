**
  ***************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32N6xx devices support on MDK-ARM.
  ***************************************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *************************************************************************************************
  Package general purpose:
  ===============================================================================================================================
	 These packages contains the needed files to be installed in order to support STM32N6xx
	 devices by MDK-ARM v5.39 and laters.

	We inform you that this package is suitable for internal & external use.
  
  Running the "Keil.STM32N6xx_DFP.1.0.0.pack" adds the following: 
  ================================================================================================================================ 
	1. Part numbers for  :
	    - Product lines with 0KB Flash size: STM32N657xx0xx/STM32N647xx0xx/STM32N655xx0xx/STM32N645xx0xx.   
	
	2. The following SVD files will be added:
		- STM32N657, STM32N655, STM32N647 & STM32N645 SVD files v1r0.
  
  How to use:
  =================================================================================================================================
  * Before installing the files mentioned above, you need to have MDK-ARM v5.25 or later installed. 
  You can download pack from keil web site @ www.keil.com
 
  * Double Clic on "Keil.STM32N6xx_DFP.1.0.0.pack" in order to install this pack in the Keil install 
  directory.
  
  PS: Please make sure that you are using PackUnzip.exe to run this pack.
	
 SVD files ReleaseNotes:
 ==================================================================================================================================
	=======================================================
	STM32N6xx_v1r0:     Official release
	=======================================================
	V1.0   First release